from django.urls import path
from .views import UserRegistrationView, BookListCreateView, BookDetailView

urlpatterns = [
    path('register/', UserRegistrationView.as_view(), name='register'),
    path('books/', BookListCreateView.as_view(), name='book-list-create'),
    path('books/<int:pk>/', BookDetailView.as_view(), name='book-detail'),
]
