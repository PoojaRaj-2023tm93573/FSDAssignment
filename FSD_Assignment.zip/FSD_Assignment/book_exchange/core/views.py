from django.shortcuts import render
from django.shortcuts import render, redirect
# Create your views here.
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from .serializers import UserRegistrationSerializer
from .forms import UserRegistrationForm 
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.auth import login, authenticate

from django.contrib.auth.forms import AuthenticationForm  # Add this import
from django.contrib.auth import authenticate, login as auth_login
#from .forms import BookSearchForm
from .models import Book
from django.core.paginator import Paginator

from django.contrib.auth import logout

def user_logout(request):
    logout(request)
    return redirect('login')  # Redirect to login page after logout

from twilio.rest import Client
import random

def send_otp(phone_number):
    client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
    otp = random.randint(100000, 999999)  # Generate a 6-digit OTP

    message = client.messages.create(
        body=f"Your OTP code is {otp}",
        from_=settings.TWILIO_PHONE_NUMBER,
        to=phone_number
    )
    return otp   
#def login(request):
 #   if request.method == 'POST':
  #      form = AuthenticationForm(request, data=request.POST)
   #     if form.is_valid():
    #        # Authenticate the user and log them in
     #       user = form.get_user()
      #      auth_login(request, user)
       #     
        #    # Redirect to the home page (or bookshelf share page)
         #   return redirect('home')  # Assuming 'home' is the name of your home page URL
    #else:
     #   form = AuthenticationForm()

    #return render(request, 'core/login.html', {'form': form})

from .forms import UserLoginForm
from django.contrib import messages

def user_login(request):
    if request.method == 'POST':
        form = UserLoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']

            # Authenticate user
            user = authenticate(request, username=username, password=password)

            if user is not None:
                # If authentication is successful, log the user in
                login(request, user)
                return redirect('home')  # Redirect to home page or dashboard after successful login
            else:
                # If authentication fails, show an error message
                messages.error(request, 'Invalid username or password.')
    else:
        form = UserLoginForm()

    return render(request, 'core/login.html', {'form': form})

def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
           # form.save()  # Save the user to the database
           # return redirect('login')  # Redirect to the login page
           username = form.cleaned_data['username']
           password = form.cleaned_data['password']

            # Ensure the password is hashed
           user = User.objects.create_user(username=username, password=password)
           user.save()
           return redirect('login')
    else:
        form = UserRegistrationForm()  # Show an empty form

    return render(request, 'core/register.html', {'form': form})


def home(request):
    return render(request, 'core/home.html') 

class UserRegistrationView(APIView):
    def post(self, request):
        serializer = UserRegistrationSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

from rest_framework import generics
from .models import Book
from .serializers import BookSerializer
from rest_framework.permissions import IsAuthenticated

from django.shortcuts import render, redirect, get_object_or_404
from .models import Book
from .forms import BookForm
from django.contrib.auth.decorators import login_required

@login_required
def add_book(request):
    if request.method == 'POST':
        form = BookForm(request.POST)
        if form.is_valid():
            book = form.save(commit=False)
            book.user = request.user
            book.save()
            return redirect('home')
    else:
        form = BookForm()
    return render(request, 'core/add_book.html', {'form': form})

from .forms import BookForm
from django.contrib.auth.decorators import login_required

from django.shortcuts import render
from .models import Book

def book_list(request):
    books = Book.objects.filter(user=request.user)  # Show books belonging to the logged-in user
    return render(request, 'core/book_list.html', {'books': books})

@login_required
def delete_book(request, book_id):
    book = get_object_or_404(Book, id=book_id, user=request.user)
    if request.method == 'POST':
        book.delete()
        return redirect('book_list')  # Redirect to book listing page after deletion
    return render(request, 'core/confirm_delete.html', {'book': book})
    
class BookListCreateView(generics.ListCreateAPIView):
    queryset = Book.objects.all()
    serializer_class = BookSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

class BookDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Book.objects.all()
    serializer_class = BookSerializer
    permission_classes = [IsAuthenticated]

# core/views.py



from .models import Book
#from .forms import BookSearchForm
from .forms import BookSearchFormNew  # Change name here


#def book_search(request):
 #   form = BookSearchFormNew(request.GET or None)
  #  books = Book.objects.all()

   # if form.is_valid():
        #title = form.cleaned_data.get('title')
    #    author = form.cleaned_data.get('author')
       # genre = form.cleaned_data.get('genre')
      #  location = form.cleaned_data.get('location')
     #   availability = form.cleaned_data.get('availability')

        #if title:
        #    books = books.filter(title__icontains=title)
        #if author:
          #  books = books.filter(author__icontains=author)
       # if genre:
         #   books = books.filter(genre__icontains=genre)
   # if location:
       #     books = books.filter(location__icontains=location)
        #if availability:
          #  books = books.filter(availability=(availability == 'True'))

    # Implement pagination
    #paginator = Paginator(books, 10)  # Show 10 books per page.
    #page_number = request.GET.get('page')
    #books_page = paginator.get_page(page_number)
    

    #return render(request, 'core/book_search.html', {'form': form, 'books': books})

def book_search(request):
    books = None  # Start with no books to avoid showing anything before the form is submitted

    # Check if search parameters are present in the GET request
    if request.method == 'GET':
        title_query = request.GET.get('title', '').strip()
        author_query = request.GET.get('author', '').strip()
        genre_query = request.GET.get('genre', '').strip()
        availability_query = request.GET.get('availability', '').strip()
        condition_query = request.GET.get('condition', '').strip()
        location_query = request.GET.get('location', '').strip()
        # Initialize an empty queryset
        books = Book.objects.all()

        # Apply filters only if search terms are provided
        if title_query:
            books = books.filter(title__icontains=title_query)
        if author_query:
            books = books.filter(author__icontains=author_query)
        if genre_query:
            books = books.filter(genre__icontains=genre_query)
        if availability_query:
            books = books.filter(availability_status=(availability_query == 'Available'))
        if condition_query:
            books = books.filter(condition=condition_query)
        if location_query:
            books = books.filter(location__icontains=location)
    

        # Paginate the results (e.g., 10 books per page)
    paginator = Paginator(books, 10)  # Show 10 books per page
    page_number = request.GET.get('page')  # Get the current page number from the GET parameters
    page_obj = paginator.get_page(page_number)  # Get the corresponding page

    # Render the template with the books (or empty if no search was performed)
    return render(request, 'core/book_search.html', {'page_obj': page_obj})


def book_detail(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    return render(request, 'core/book_detail.html', {'book': book})


@login_required
def edit_book(request, book_id):
    book = get_object_or_404(Book, id=book_id, user=request.user)  # Ensure the user can only edit their own books

    if request.method == 'POST':
        form = BookForm(request.POST, instance=book)
        if form.is_valid():
            form.save()
            return redirect('book_list')  # Redirect to the book listing page or search results page
    else:
        form = BookForm(instance=book)  # Populate form with current book data

    return render(request, 'core/edit_book.html', {'form': form, 'book': book})

from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from django.core.mail import send_mail

def send_password_reset_email(request):
    # Example email input from the form
    email = request.POST.get('email')  # Or use a form to get the email
    user = get_user_model().objects.filter(email=email).first()

    if user:
        # Generate the password reset link
        uid = urlsafe_base64_encode(user.pk.encode())
        token = default_token_generator.make_token(user)
        reset_link = f"http://{get_current_site(request).domain}/reset/{uid}/{token}/"

        # Print the reset link to the console
        print("Password Reset Link: ", reset_link)  # This will print it in the console

        # Optionally, send the email
        send_mail(
            'Password Reset Request',
            f'Click the link to reset your password: {reset_link}',
            'from@example.com',
            [user.email],
            fail_silently=False,
        )

        return HttpResponse('A password reset link has been sent to your email.')

    else:
        return HttpResponse('Email not found.')

def send_password_reset_email(request):
    email = request.POST.get('email')
    user = get_user_model().objects.filter(email=email).first()

    if user:
        # Generate the password reset link
        uid = urlsafe_base64_encode(user.pk.encode())
        token = default_token_generator.make_token(user)
        reset_link = f"http://{get_current_site(request).domain}/reset/{uid}/{token}/"

        # Optionally, you can send the email
        send_mail(
            'Password Reset Request',
            f'Click the link to reset your password: {reset_link}',
            'from@example.com',
            [user.email],
            fail_silently=False,
        )

        # Pass the reset link to the template
        return render(request, 'core/reset_link_display.html', {'reset_link': reset_link})

    else:
        return HttpResponse('Email not found.')

# core/views.py
# views.py
from django.conf import settings
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from twilio.rest import Client
from django.core.exceptions import ObjectDoesNotExist
from django.contrib import messages
import random
import string
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.contrib.auth.tokens import default_token_generator
#from django.utils.encoding import force_bytes, force_text

def generate_otp():
    """Generate a random 6-digit OTP."""
    otp = ''.join(random.choices(string.digits, k=6))
    return otp

def send_otp_to_phone_number(phone_number, otp):
    """Send OTP to user's phone number via Twilio."""
    client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
    message = client.messages.create(
        body=f'Your OTP for password reset is: {otp}',
        from_=settings.TWILIO_PHONE_NUMBER,
        to=phone_number
    )
    return message.sid

def otp_password_reset(request):
    if request.method == 'POST':
        users = User.objects.filter(email='sam@gmail.com')
        
        if users.exists():
            # Assume you're selecting the first user, or handle multiple users as needed
            user = users.first()  # You can change this logic based on your requirements

            # Generate the OTP and send it to the user's phone
            otp = generate_otp()  # Implement this function to generate the OTP

            # Send the OTP to user's phone number
            send_otp_to_phone(user.profile.phone_number, otp)  # Assuming you have a profile model with phone number

            messages.success(request, "OTP sent successfully to your phone.")
            return redirect('verify_otp')  # Redirect to OTP page
        else:
            messages.error(request, "Email not found!")
    
    return render(request, 'core/otp_password_reset.html')

# views.py (cont.)
def verify_otp(request):
    if request.method == 'POST':
        entered_otp = request.POST.get('otp')
        actual_otp = request.session.get('otp')

        if entered_otp == actual_otp:
            # OTP is correct, redirect to reset password page
            return redirect('reset_password')
        else:
            messages.error(request, 'Invalid OTP, please try again.')
            return redirect('verify_otp')

    return render(request, 'core/verify_otp.html')

from django.contrib.auth.views import PasswordResetConfirmView
from django.shortcuts import redirect
from django.contrib.auth.forms import SetPasswordForm
from django.contrib.auth.models import User
from django.contrib.auth.forms import SetPasswordForm
from django.views import View
class CustomPasswordResetConfirmView(View):
    def get(self, request, uidb64, token):
        try:
            uid = urlsafe_base64_decode(uidb64).decode()
            user = get_user_model().objects.get(pk=13)
            if default_token_generator.check_token(user, token):
                # If token is valid, show password reset form
                form = SetPasswordForm(user=user)
                return render(request, 'core/password_reset_confirm.html', {'form': form})
            else:
                # Invalid token
                return redirect('password_reset')
        except (TypeError, ValueError, OverflowError, user.DoesNotExist):
            # Invalid UID or user does not exist
            return redirect('password_reset')


# views.py
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import UserProfile
from django.contrib.auth.models import User

def reset_password_security(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        security_answer = request.POST.get('security_answer')
        new_password = request.POST.get('new_password')

        try:
            user = User.objects.get(username=username)
            profile = UserProfile.objects.get(user=user)

            # Check if the security answer matches
            if profile.security_answer.lower() == security_answer.lower():
                user.set_password(new_password)
                user.save()
                messages.success(request, 'Password reset successful.')
                return redirect('login')
            else:
                messages.error(request, 'Incorrect security answer. Please try again.')

        except User.DoesNotExist:
            messages.error(request, 'User does not exist.')
        except UserProfile.DoesNotExist:
            messages.error(request, 'User profile does not exist for the given user.')

    else:
        username = request.GET.get('username')
        security_question = request.GET.get('security_question')

        if username:
            try:
                user = User.objects.get(username=username)
                profile = UserProfile.objects.get(user=user)
                security_question = profile.security_question
            except (User.DoesNotExist, UserProfile.DoesNotExist):
                messages.error(request, 'User or profile does not exist for the given username.')
                return redirect('reset_password_security')

        # Render the template with the security question (if available)
        return render(request, 'reset_password_security.html', {'security_question': security_question, 'username': username})

    # If GET or error in POST, render template without redirect
    return render(request, 'reset_password_security.html', {})

from django.shortcuts import render

def reset_password_view(request):
    return render(request, 'core/reset_password.html')  # Assuming the HTML is saved in the 'core' app templates folder

# views.py
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
from django.contrib import messages
from .forms import SimplePasswordResetForm

def simple_password_reset(request):
    if request.method == 'POST':
        form = SimplePasswordResetForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            new_password = form.cleaned_data.get('new_password')

            try:
                user = User.objects.get(username=username)
                user.set_password(new_password)
                user.save()

                # After resetting the password, you may log them in or redirect them
                messages.success(request, "Your password has been successfully reset.")
                return redirect('login')  # Or wherever you'd like to redirect
            except User.DoesNotExist:
                messages.error(request, "Email address not found.")
    else:
        form = SimplePasswordResetForm()

    return render(request, 'core/simple_password_reset.html', {'form': form})
