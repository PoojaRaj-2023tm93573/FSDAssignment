from django.db import models

# Create your models here.
from django.db import models
from django.contrib.auth.models import User
import uuid



class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    security_question = models.CharField(max_length=255)
    security_answer = models.CharField(max_length=255)
    phone_number = models.CharField(max_length=15, unique=True, null=True, blank=True)  

    def __str__(self):
        return f"Profile of {self.user.username}"


class Book(models.Model):
    unique_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)  # Custom unique ID
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='books')
    title = models.CharField(max_length=255)
    author = models.CharField(max_length=255)
    genre = models.CharField(max_length=100)
    condition = models.CharField(max_length=50)
    availability_status = models.BooleanField(default=True)
    location = models.CharField(max_length=100) 
    created_at = models.DateTimeField(auto_now_add=True)
    
   # def __str__(self):
   #     return self.title

    def __str__(self):
        return f"{self.title} by {self.author}"
