# core/forms.py
from django import forms
from django.contrib.auth.models import User
from .models import Book 

class UserRegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    confirm_password = forms.CharField(widget=forms.PasswordInput)
    security_question = forms.CharField(max_length=255, required=True)
    security_answer = forms.CharField(max_length=255, required=True, widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ['username', 'email', 'password']

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get('password')
        confirm_password = cleaned_data.get('confirm_password')

        if password != confirm_password:
            raise forms.ValidationError("Passwords don't match")
        return cleaned_data

    def save(self, commit=True):
        # Save the user instance
        user = super().save(commit=False)
        user.set_password(self.cleaned_data['password'])
        
        if commit:
            user.save()
            # Create the UserProfile instance with security question and answer
            UserProfile.objects.create(
                user=user,
                security_question=self.cleaned_data['security_question'],
                security_answer=self.cleaned_data['security_answer']
            )
        return user
    

class UserLoginForm(forms.Form):
    username = forms.CharField(max_length=150)
    password = forms.CharField(widget=forms.PasswordInput)


class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = ['title', 'author', 'genre', 'condition', 'availability_status','location']

from django import forms

class BookSearchFormNew(forms.Form):  # Change name here
    title = forms.CharField(required=False, label="Title")
    author = forms.CharField(required=False, label="Author")
    genre = forms.CharField(required=False, label="Genre")
    location = forms.CharField(required=False, max_length=100) 
    availability = forms.ChoiceField(
        choices=[('Available', 'Available'), ('Unavailable', 'Unavailable')],
        required=False,
        label="Availability"
    )
    condition = forms.ChoiceField(
        choices=[('New', 'New'), ('Good', 'Good'), ('Fair', 'Fair'), ('Poor', 'Poor')],
        required=False,
        label="Condition"
    )


# core/forms.py






